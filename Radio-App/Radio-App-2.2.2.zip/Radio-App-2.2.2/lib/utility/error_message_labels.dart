const noInternet = 'no-internet';
