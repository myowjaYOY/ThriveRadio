import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:radio_online/repository/radio_station_repo.dart';

enum AppSettingsStatus { initial, loading, success, failure }

class AppSettingsState {
  AppSettingsState({
    this.status = AppSettingsStatus.initial,
    this.error,
  });

  final AppSettingsStatus status;
  final String? error;

  AppSettingsState copyWith({
    AppSettingsStatus? status,
    String? error,
  }) {
    return AppSettingsState(
      status: status ?? this.status,
      error: error ?? this.error,
    );
  }
}

class AppSettingsCubit extends Cubit<AppSettingsState> {
  AppSettingsCubit() : super(AppSettingsState());

  Future<void> fetchAppSettings() async {
    emit(state.copyWith(status: AppSettingsStatus.loading));
    try {
      await RadioStationRepo().getAppSettings();

      emit(state.copyWith(status: AppSettingsStatus.success));
    } catch (e) {
      emit(
        state.copyWith(
          status: AppSettingsStatus.failure,
          error: e.toString(),
        ),
      );
    }
  }
}
